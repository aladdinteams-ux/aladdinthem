<?php
defined('ABSPATH') || exit;
function frpme_native_map(){static $map;if(null===$map){$path=FRPME_DIR.'data/native-map.json';$map=file_exists($path)?json_decode(file_get_contents($path),true):array();}return is_array($map)?$map:array();}
// Elements that do not belong to FRP never pay for decoding the 170 KB map.
function frpme_native_meta($element){$k=$element->get_settings('frpme_native');if(!is_string($k)||''===$k)return false;$map=frpme_native_map();return isset($map[$k])?$map[$k]:false;}
function frpme_native_controls($element,$section){
 if(!in_array($element->get_name(),array('container','heading','text-editor','button','icon','image','video','html','frpme-field','frpme-data','theme-post-title','theme-post-excerpt','theme-post-content'),true))return;
 if(!$element->get_controls('frpme_native')){$element->add_control('frpme_native',array('type'=>\Elementor\Controls_Manager::HIDDEN,'default'=>''));}
 foreach($element->get_controls() as $key=>$control){if(empty($control['selectors'])||!is_array($control['selectors']))continue;
 // Controls that default to Elementor Global Colors/Fonts (button background = accent, typography = accent...) must not get the boosted selector: it would repaint every FRP button and font over the original design.
 if(!empty($control['global']['default'])||(isset($control['groupType'])&&'typography'===$control['groupType']))continue;
 $selectors=$control['selectors'];$changed=false;
 foreach($control['selectors'] as $selector=>$rule){if(0!==strpos($selector,'{{WRAPPER}}')||false!==strpos($selector,'frpme-native-leaf'))continue;
 $alias=str_replace('{{WRAPPER}}','body.frpme-body {{WRAPPER}}.frpme-native-leaf',$selector);$alias=str_replace('.elementor-widget-container','.frpme-native-node',$alias);$alias=str_replace('.elementor-icon svg','svg.elementor-icon',$alias);$selectors[$alias]=$rule;$changed=true;
 if(preg_match('/^\{\{WRAPPER\}\}(:(?:hover|focus))?$/',$selector,$m)){$selectors['body.frpme-body {{WRAPPER}}.frpme-native-leaf > .frpme-native-node'.(isset($m[1])?$m[1]:'')]=$rule;}
 if('icon'===$element->get_name()&&false!==strpos($rule,'font-size:')){$selectors['body.frpme-body {{WRAPPER}}.frpme-native-leaf svg.elementor-icon']=str_replace('font-size:','width:',$rule).str_replace('font-size:','height:',$rule);}
 }if($changed){$element->update_control($key,array('selectors'=>$selectors));}}
}
add_action('elementor/element/before_section_end','frpme_native_controls',10,2);
function frpme_native_attrs($attrs,$extra=''){$attrs['class']=trim((isset($attrs['class'])?$attrs['class']:'').' frpme-native-node '.$extra);$out='';foreach($attrs as $key=>$v){if(preg_match('/^(?:class|id|title|width|height|loading|decoding|fetchpriority|role|tabindex|lang|dir|type|name|value|min|max|step|required|checked|hidden|open|for|rows|maxlength|inputmode|placeholder|autocomplete|pattern|disabled|readonly|multiple|aria-[a-z-]+|data-[a-z-]+|style)$/',$key)){$out.=' '.esc_attr($key).'="'.esc_attr($v).'"';}}return $out;}
function frpme_native_tree($value){if(is_array($value)){foreach($value as $k=>$v){$value[$k]=frpme_native_tree($v);}}elseif(is_string($value)){$value=frpme_resolve($value);}return $value;}
function frpme_native_icon($s){$icon=isset($s['selected_icon'])?frpme_native_tree($s['selected_icon']):array();if(empty($icon['value']))return '';if(isset($icon['value']['url'])&&0===strpos($icon['value']['url'],FRPME_URL.'assets/icons/')){$name=basename($icon['value']['url']);if(preg_match('/^i-[a-z0-9-]+\.svg$/',$name)&&file_exists(FRPME_DIR.'assets/icons/'.$name)){return str_replace('<svg ','<svg class="icon" ',file_get_contents(FRPME_DIR.'assets/icons/'.$name));}}ob_start();\Elementor\Icons_Manager::render_icon($icon,array('aria-hidden'=>'true','class'=>'icon'));return ob_get_clean();}
function frpme_native_kses($v){$allowed=wp_kses_allowed_html('post');$allowed['bdi']=array('dir'=>true,'lang'=>true,'class'=>true);return wp_kses(frpme_resolve($v),$allowed);}
function frpme_native_render($content,$widget){$m=frpme_native_meta($widget);if(!$m)return $content;$s=$widget->get_settings_for_display();$t=$m['tag'];$a=$m['attrs'];$name=$widget->get_name();$extra='';
 if('heading'===$name){$v=frpme_native_kses(isset($s['title'])?$s['title']:'');$extra='elementor-heading-title';if(in_array(isset($s['header_size'])?$s['header_size']:'',array('h1','h2','h3','h4','h5','h6'),true))$t=$s['header_size'];if(!empty($m['empty'])&&isset($s['title'])&&"\xE2\x80\x8B"===$s['title'])$v='';if(!empty($s['link']['url']))$v='<a href="'.esc_url(frpme_resolve($s['link']['url'])).'">'.$v.'</a>';}
 elseif('text-editor'===$name){$v=frpme_native_kses(isset($s['editor'])?$s['editor']:'');$extra='elementor-text-editor';}
 elseif('button'===$name){$v=frpme_native_kses(isset($s['text'])?$s['text']:'');$icon=frpme_native_icon($s);if(!empty($m['empty_button'])&&isset($s['text'])&&"\xE2\x80\x8B"===$s['text'])$v='';$v=!empty($m['icon_before'])?$icon.$v:$v.$icon;$extra='elementor-button';if('a'===$t){$a['href']=frpme_resolve(isset($s['link']['url'])?$s['link']['url']:'');if(!empty($s['link']['is_external'])){$a['target']='_blank';$a['rel']='noopener noreferrer';}}}
 elseif('image'===$name){$url=frpme_resolve(isset($s['image']['url'])?$s['image']['url']:'');if(!empty($s['image']['id'])){$url=wp_get_attachment_image_url((int)$s['image']['id'],'full')?:$url;$a['alt']=get_post_meta((int)$s['image']['id'],'_wp_attachment_image_alt',true);}if(!empty($m['site_logo'])&&empty($s['image']['id'])&&$url===frpme_resolve(isset($m['default_image'])?$m['default_image']:'')){$logo=(int)frpme_setting('logo_id',get_theme_mod('custom_logo'));if($logo)$url=wp_get_attachment_image_url($logo,'full')?:$url;}$out='<img'.frpme_native_attrs($a,'elementor-image').' src="'.esc_url($url).'" alt="'.esc_attr(isset($a['alt'])?$a['alt']:'').'">';if('custom'===(isset($s['link_to'])?$s['link_to']:'')&&!empty($s['link']['url']))$out='<a href="'.esc_url(frpme_resolve($s['link']['url'])).'">'.$out.'</a>';return $out;}
 elseif('icon'===$name){$icon=frpme_native_icon($s);$icon=preg_replace('/^(<svg\b[^>]*?)\sclass="[^"]*"/','$1',$icon,1);return preg_replace('/<svg\b/','<svg'.frpme_native_attrs($a,'elementor-icon'),$icon,1);}
 elseif('video'===$name){if(isset($s['video_type'])&&'hosted'!==$s['video_type'])return $content;$url=isset($s['hosted_url']['url'])?frpme_resolve($s['hosted_url']['url']):'';$global=frpme_setting('video_url');if($global&&(!$url||$url===frpme_resolve(isset($m['default_video'])?$m['default_video']:'')))$url=$global;$poster=isset($s['poster']['url'])?frpme_resolve($s['poster']['url']):'';return '<video'.frpme_native_attrs($a).' controls preload="metadata"'.($poster?' poster="'.esc_url($poster).'"':'').'><source src="'.esc_url($url).'" type="video/mp4"></video>';}
 elseif(in_array($name,array('theme-post-title','theme-post-excerpt','theme-post-content'),true)){$types=array('theme-post-title'=>'post-title','theme-post-excerpt'=>'post-excerpt','theme-post-content'=>'post-content');$v=frpme_dynamic($types[$name],'native',$s);}
 elseif('html'===$name){return wp_kses(frpme_resolve(isset($s['html'])?$s['html']:''),array('iframe'=>array('src'=>true,'title'=>true,'width'=>true,'height'=>true,'loading'=>true,'allowfullscreen'=>true,'referrerpolicy'=>true)));}
 else{return $content;}
 $links='';foreach(array('href','target','rel') as $k){if(isset($a[$k]))$links.=' '.$k.'="'.('href'===$k?esc_url($a[$k]):esc_attr($a[$k])).'"';}return '<'.$t.frpme_native_attrs($a,$extra).$links.'>'.$v.'</'.$t.'>';
}
add_filter('elementor/widget/render_content','frpme_native_render',20,2);
function frpme_native_before($el){$m=frpme_native_meta($el);if(!$m)return;if('container'===$el->get_name()){ob_start();}else{$el->add_render_attribute('_wrapper','class','frpme-native-leaf');}}
function frpme_native_after($el){$m=frpme_native_meta($el);if(!$m||'container'!==$el->get_name())return;$out=ob_get_clean();$a=$m['attrs'];$s=$el->get_data('settings');$a['class']=trim((isset($s['css_classes'])?$s['css_classes']:(isset($a['class'])?$a['class']:'')).' frpme-native-box elementor-element elementor-element-'.$el->get_id());if(!empty($s['_element_id']))$a['id']=$s['_element_id'];if('a'===$m['tag']&&isset($s['link']['url']))$a['href']=frpme_resolve($s['link']['url']);if('p'===$m['tag'])$out=preg_replace('/<(\/?)div(\s[^>]*|)>/i','<$1span$2>',$out);
 $open='<'.$m['tag'];preg_match('/^\s*<[a-z][^>]*>/i',$out,$boundary);if(preg_match('/\bdata-settings=([\"\'])[^\"\']*\1/',isset($boundary[0])?$boundary[0]:'',$match))$open.=' '.$match[0];foreach($a as $k=>$v){if(!preg_match('/^on/i',$k))$open.=' '.esc_attr($k).'="'.('href'===$k?esc_url($v):esc_attr($v)).'"';}$open.=' data-id="'.esc_attr($el->get_id()).'" data-element_type="container">';$out=preg_replace('/^\s*<[a-z][^>]*>/i',$open,$out,1);$out=preg_replace('/<\/[a-z]+>\s*$/i','</'.$m['tag'].'>',$out,1);echo $out; // Trusted semantic boundary, rendered children remain Elementor output.
}
add_action('elementor/frontend/before_render','frpme_native_before',1);add_action('elementor/frontend/after_render','frpme_native_after',999);
function frpme_native_preview(){$icons=array();foreach(glob(FRPME_DIR.'assets/icons/i-*.svg') as $file){$icons[basename($file)]=file_get_contents($file);}wp_enqueue_script('frpme-native-preview',FRPME_URL.'assets/js/native-preview.js',array(),frpme_version('assets/js/native-preview.js'),true);wp_add_inline_script('frpme-native-preview','window.FrpMeshNativeData='.wp_json_encode(array('map'=>frpme_native_map(),'url'=>FRPME_URL,'home'=>home_url('/'),'icons'=>$icons,'logo_url'=>wp_get_attachment_image_url((int)frpme_setting('logo_id',get_theme_mod('custom_logo')),'full'),'video_url'=>frpme_setting('video_url')),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).';','before');}
add_action('elementor/preview/enqueue_scripts','frpme_native_preview');add_action('elementor/editor/after_enqueue_scripts','frpme_native_preview');
add_filter('elementor/widget/print_template',function($template,$widget){if(in_array($widget->get_name(),array('heading','text-editor','button','icon','image','video','html'),true)){return '<# if(settings.frpme_native && window.FrpMeshNative){ #>{{{ window.FrpMeshNative.render("'.esc_js($widget->get_name()).'",settings) }}}<# }else{ #>'.$template.'<# } #>';}return $template;},20,2);
// frpme_source() calls this for ordinary pages on every request: skip the JSON decode unless the marker is present.
function frpme_native_raw_data($id){$raw=get_post_meta($id,'_elementor_data',true);return is_string($raw)&&false!==strpos($raw,'frpme_native')?$raw:'';}
function frpme_native_document($id){$raw=frpme_native_raw_data($id);if(''===$raw)return false;$d=json_decode($raw,true);if(!is_array($d))return false;$scan=function($ns)use(&$scan){foreach($ns as $n){if(!empty($n['settings']['frpme_native']))return true;if(!empty($n['elements'])&&$scan($n['elements']))return true;}return false;};return $scan($d);}
function frpme_native_document_source($id){$raw=frpme_native_raw_data($id);if(''===$raw)return '';$d=json_decode($raw,true);if(!is_array($d))return '';$map=frpme_native_map();$scan=function($ns)use(&$scan,$map){foreach($ns as $n){$k=isset($n['settings']['frpme_native'])?$n['settings']['frpme_native']:'';if(isset($map[$k]['attrs']['data-frpme-source']))return $map[$k]['attrs']['data-frpme-source'];if(!empty($n['elements'])){$s=$scan($n['elements']);if($s)return $s;}}return '';};return $scan($d);}
/**
 * Elementor adds "global default" rules such as `.elementor-widget-button .elementor-button{background-color:var(--e-global-color-accent)}`
 * to every document's CSS. Their specificity beats the original FRP classes (.btn-primary, tabs, headings…), so buttons turned
 * green and fonts changed. FRP documents bring their own complete styling, so these widget-level defaults are removed from the
 * generated CSS of FRP documents only. Rules written for an individual element (user edits) are untouched, as is every other page.
 */
function frpme_strip_global_defaults($css_file){
 if(!is_object($css_file)||!method_exists($css_file,'get_post_id')||!method_exists($css_file,'get_stylesheet'))return;
 $post_id=(int)$css_file->get_post_id();
 if(!$post_id||!frpme_native_document($post_id))return;
 try{
  $sheet=$css_file->get_stylesheet();
  $prop=new ReflectionProperty($sheet,'rules');$prop->setAccessible(true);$rules=$prop->getValue($sheet);
  if(!is_array($rules))return;
  $pattern='/^\s*\.elementor-widget-(?:heading|text-editor|button|icon|image|video|html|frpme-field|frpme-data|theme-post-title|theme-post-excerpt|theme-post-content)(?![\w-])/';
  foreach($rules as $query=>$by_selector){
   if(!is_array($by_selector))continue;
   foreach(array_keys($by_selector) as $selector){
    // Every comma-separated part must be a widget-level default for the rule to be dropped.
    $parts=array_filter(array_map('trim',explode(',',(string)$selector)));
    if($parts&&count(preg_grep($pattern,$parts))===count($parts))unset($rules[$query][$selector]);
   }
  }
  $prop->setValue($sheet,$rules);
 }catch(\Throwable $e){return;}
}
add_action('elementor/css-file/post/parse','frpme_strip_global_defaults');
